/**
 *
 * @author yarit
 */
import java.util.ArrayList;
import java.util.List;

public class GestorEmpleados {
    private final List<Empleado> listaEmpleados;

   
    public GestorEmpleados() {
        listaEmpleados = new ArrayList<>();
    }

    public void agregarEmpleado(Empleado empleado) {
        listaEmpleados.add(empleado);
        System.out.println("Empleado agregado con éxito.");
    }


    public void mostrarEmpleados() {
        if (listaEmpleados.isEmpty()) {
            System.out.println("No hay empleados registrados.");
        } else {
            System.out.println("Lista de empleados:");
            for (Empleado emp : listaEmpleados) {
                emp.mostrarInformacion();
            }
        }
    }
}