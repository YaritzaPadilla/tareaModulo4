

/**
 *
 * @author yarit
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            GestorEmpleados gestor = new GestorEmpleados();
            
            int opcion;
            do {
                System.out.println("\n--- Menú de Gestión de Empleados ---");
                System.out.println("1. Agregar empleado");
                System.out.println("2. Mostrar empleados");
                System.out.println("3. Salir");
                System.out.print("Seleccione una opción: ");
                opcion = scanner.nextInt();
                scanner.nextLine();  
                
                switch (opcion) {
                    case 1 -> {
                        System.out.print("Ingrese el nombre: ");
                        String nombre = scanner.nextLine();
                        System.out.print("Ingrese la edad: ");
                        int edad = scanner.nextInt();
                        System.out.print("Ingrese el salario: ");
                        double salario = scanner.nextDouble();
                        
                        Empleado nuevoEmpleado = new Empleado(nombre, edad, salario);
                        gestor.agregarEmpleado(nuevoEmpleado);
                    }
                        
                    case 2 -> gestor.mostrarEmpleados();
                        
                    case 3 -> System.out.println("Saliendo del sistema...");
                        
                    default -> System.out.println("Opción no válida. Intente de nuevo.");
                }
            } while (opcion != 3);
        }
    }
}
